function Indent(tabsCount, string) {
   this.tabsCount = tabsCount;
   let indent = "";
   for (let i = 0; i < tabsCount; i++) {
      indent += Indent.tab;
   }
      
   this.addTabs = function(string) {
      let lines = string.split("\n");
      for (let index in lines) {
         lines[index] = indent + lines[index];
      }
      return lines.join("\n");
   }
   
   if (string != undefined)
      this.string = this.addTabs(string.toString());

   this.toString = function() {
      return this.string;
   }
}

Indent.tab = "   ";