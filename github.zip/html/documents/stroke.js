function Stroke(p) {
    this.push(p);
}
Stroke.prototype = new Array();

function Toucjemmmm(stroke, identifier) {
    stroke.identifier = identifier;
    this.push(stroke);