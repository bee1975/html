<?php
print_r(apache_get_modules());
?>