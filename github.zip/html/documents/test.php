<?php
print $_SERVER['QUERY_STRING'];
/*
print "<html><body><textarea onblur=eval(value)></textarea></body></html>"; 
*/
?>