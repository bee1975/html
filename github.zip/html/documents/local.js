afunction This(script) {
    alertProperties(script);
}