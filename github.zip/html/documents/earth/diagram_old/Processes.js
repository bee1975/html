function Processes(inputs) {
	return {
		_function : Process({process : Proceesses, inputs : inputs}),
		outputs : Sequence( {
			before : funct
		})
	}
}
