function Outputs(inputs) {

	var outputs = new Object();

	outputs.inputs = inputs.inputs;
    outputs.process = inputs.process;

	return outputs;

}


