function Document_20Context() {
    Context.call(this);
    this.document = window.document;
}