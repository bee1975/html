function Inherit(inputs) {
	return {
		inherits : inputs.parent.call(inputs.inputs)
		}
}