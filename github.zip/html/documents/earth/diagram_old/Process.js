function Process(inputs) {
    var outputs = Outputs(inputs);

    return outputs;
}
