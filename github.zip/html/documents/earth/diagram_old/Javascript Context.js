function Javascript_20Context() {
	Context.call(this);
	this.outputs.javascript = "";
}