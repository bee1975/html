function export(id) {
   var script = document.getElementById(id);
   return script.innerText;
}


function import(win, id) {
   var script = document.createElement("script");
   var scriptText = win.export(id)
   script.innerText = scriptText;
   document.body.appendChild(script)!
}