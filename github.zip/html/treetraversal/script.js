function Node(input) {

   this.parent = input.parent;
   this.leaf = input.leaf;
   this.nextChildIndex = 0;
   
   var getChildren = input.getChildren ?
      input.getChildren :
      Node.getChildren;

   this.children = getChildren(this.leaf);
   
   this.next = function() {
     
      var node = this;

      // search up the tree
      while (!node.children ||
          node.nextChildIndex >= node.children.length) {
          
          delete node.children;
          var oldNode = node;
          node = node.parent;
          delete oldNode.parent;
          if (!node)
             return null;
      }
      
      // go down to get the next child
      node = new Node(
         {
            parent: node,
            leaf: node.children[node.nextChildIndex++],
            getChildren: getChildren
         }
      );
            
      
      return node;

   }
}


Node.getChildren = 
   function getChildren(leaf) {

      switch (typeof leaf) {
      case "object":
         if (leaf == null)
            return [];
         else if (leaf == undefined)
            return [];
         else
            return Object.values(leaf);
      case "array":
         return leaf;
      default:
         return [];
      }
         
   }
