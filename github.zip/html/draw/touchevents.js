function TouchEvents(input) {
   var touchEvents = this;
/*
Add connections to the touch touchEvents and redirect them to the canvas so that the user can generate diagrams
*/

   var id = input.id;
   var parent = input.parent;
   
   var gesture = null;
   var startPoint = null;
   var toTouches = null;
   var point = null;
   
   var element = document.createElement("div");
   element.id = id;
   element.contentEditable = false;
   
   if (parent)
      parent.appendChild(element);

   declareEvents();
   
   this.setGesture = function(newGesture) {
      gesture = newGesture;
      switch (gesture)
      {
      case "text":
         element.contentEditable = true;
         break;
      default:
         element.contentEditable = false;
      }
   }

   function declareEvents() {
      touchEvents.onclick = function(point) {}
      touchEvents.ondoubleclick = function(point) {}
      touchEvents.oncontextmenu = function(point) {}
      touchEvents.onpendown = function(startPoint) {}
      touchEvents.onpenup = function(point) {}
      touchEvents.onmovepen = function(point) {}
      touchEvents.ontransform = function(offset, center, scale) {}
      touchEvents.ontransformpoint = function(point) {
         return point;
      }
   }
   
   // set up listeners to element.touchEvents

   element.onclick =
      function(event) {
         touchEvents.onclick(point);
      }
      
   element.ondblclick = 
      function(event) {
         event.preventDefault();
         touchEvents.ondoubleclick(point);
      }
      
   element.oncontextmenu = 
      function(event) {
         event.preventDefault();
         touchEvents.oncontextmenu(point);
      }
      
   // prevent on context menu from
   // selecting text
   element.onselectstart = 
      function(event) {
         event.preventDefault();
      }

   

   element.ontouchstart = function (event) {

      if (event.touches.length == 1) {
         // started first touch, reset
         // gesture and save the
         // start point
         gesture = null;
            
         point = startPoint = getPoint(event.touches[0]);

      }
      else {

         // started second touch,
         // finish any pen gesture,
         // set gesture to scroll
         // and save both touches
         // for use in scrolling
         if (gesture == "pen") {
            touchEvents.onpenup(point);
         }
         
         gesture = "scroll";
         toTouches = event.touches;
        
      }
      
   }
   
   if (parent == document ||
       parent == document.body) {
       // set passive to false to make sure we can capture the event to cancel the default action of refreshing or scrolling
      element.addEventListener(
         "touchmove",
         function(event) {
            event.preventDefault();
         },
         {
            passive: false,
            capture: true 
         } 
      );
   }
   
   element.ontouchmove = function(event) {
               
      event.preventDefault();
      
      fromPoints = null;
      toPoints = null;
      point = getPoint(event.touches[0]);
      
      switch (gesture) {
      case null:

         // start new pen gesture
         gesture = "pen";
         touchEvents.onpendown(startPoint);
               
      case "pen":
         // move existing pen
         touchEvents.onmovepen(point);
         break;
      case "scroll":
         // scrolling, but only if we
         // have at least two gestures
         if (event.touches.length < 2) {
            gesture = null;
            break;
         }
         
         // get points from that moved 
         // to
         // (from points -> to points)
         
         fromTouches = toTouches;

         toTouches = event.touches;
   
         toPoints = getPoints(toTouches);
      
         fromPoints = getPoints(fromTouches);
      
         // get the offset, scale and
         // center of this scrolling
         offset = getOffset();
         scale = getScale();
         center = getCenter();
 
         // scale and offset the canvas
         // geometry about the center
         // point
         touchEvents.ontransform(offset, center, scale);
         
         
         break;
      }
      

      function getScale() {

         fromDistance = fromPoints[0].distance(fromPoints[1]);
         
         toDistance = toPoints[0].distance(toPoints[1]);
         
         scale = toDistance / fromDistance;
         
         return scale;
         
      
      }
      
      function getOffset() {
        
        
         fromMiddle = fromPoints[0].middle(fromPoints[1]);
         toMiddle = toPoints[0].middle(toPoints[1]);
       
         offset = toMiddle.subtract(fromMiddle);
         
         return offset;
      }
      
      function getCenter() {
        
         center = toPoints[0].middle(toPoints[1]);
         return center;
      }

   }
   
   element.ontouchend =
   element.ontouchcancel =
      function(event) {
         
         if (gesture == "pen") {
            touchEvents.onpenup(point);
            gesture = null;
         }
      }


   function getPoint(touch) {
  
      point = new Point(
         {
            x: touch.clientX,
            y: touch.clientY
         }
      );
      
      point = touchEvents.ontransformpoint(point);
      
      return point;
   }
   
   function getPoints(touches) {
   
      points = [];
      
      for (index = 0; index < touches.length; index++) {
         touch = touches[index];
         point = getPoint(touch);
         points.push(point);
      }

      return points;
      
   }
   
}