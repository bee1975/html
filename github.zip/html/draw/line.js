function Line(input) {

   var line = this; 
   
   if (input && input.start)
      this.start = new Point(input.start);
   else
      input.start = new Point();
   
   this.points = [];
   if (input && input.points)
      input.points.forEach (
         function (point) {
            line.points.push(new Point(point));
         }
      );
   
  
   var dimensions = new Dimensions();
   
   this.ondraw = function(context) {}
   
   this.getDimensions = function() {
      return dimensions;
   }
   
   this.setDimensions = function() {
      
      var minimum = this.start;
   
      var maximum = this.start;

      this.points.forEach(
         function(point) {
     
            minimum = point.minimum(minimum);
      
            maximum = point.maximum(maximum);
         }
      );
      
      dimensions = new Dimensions(
         {
            minimum: minimum,
            maximum: maximum
         }
      );
      
   }

   this.clearDimensions = function() {
      dimensions = new Dimensions();
   }
   
   
   this.draw = function(context) {
      context.beginPath();
      context.moveTo(this.start.x, this.start.y);
      this.points.forEach(
         function(point) {
      
            context.lineTo(point.x, point.y);
         }
      );
      context.stroke();

      this.ondraw(context);
   }
   
   this.averageDistance = function(toPoint) {
   
      var sum = this.start.distance(toPoint);
      var count = 1;
      
      this.points.forEach(
         function(point) {
            sum += point.distance(toPoint);
            count++;
         }
      );
      
      return sum / count;
   }
   
   this.toString = function() {
   
      return JSON.stringify(this);
   }
   
   this.setDimensions();
}

