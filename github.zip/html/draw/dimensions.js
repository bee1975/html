function Dimensions(input) {

   if (input && input.minimum)
      this.minimum = input.minimum;
   else
      this.minimum = new Point(
         {
            x: Number.POSITIVE_INFINITY,
            y:  Number.POSITIVE_INFINITY
         }
      );
      
   if (input && input.maximum)
      this.maximum = input.maximum;
   else
      this.maximum = new Point(
         {
            x: Number.NEGATIVE_INFINITY,
            y:  Number.NEGATIVE_INFINITY
         }
      );

   this.round = function() {
      return new Dimensions(
         {
            minimum: this.minimum.round(),
            maximum: this.maximum.round()
         }
      );
   }
   
   this.draw = function(context) {
      context.strokeStyle = "yellow";
      context.fillStyle = "rgba(255,255,0,0.1)";
      context.beginPath();
      context.rect(
         this.left,
         this.top, 
         this.width,
         this.height
      );
      context.fill();
      context.stroke();
   }
   
   this.left = this.minimum.x;
   this.top = this.minimum.y;
   
   this.width = this.maximum.x - this.minimum.x;
   
   this.height = this.maximum.y - this.minimum.y;
   
   this.right = this.left + this.width;
   this.bottom = this.top + this.height;
   
   this.applyTo = function(element) {
      
      element.style.left = this.left + "px";
      element.style.top = this.top + "px";
      element.style.width = this.width + "px";
      element.style.height = this.height + "px";
   }
   
   this.toString = function() {
      return JSON.stringify(this);
   }
}