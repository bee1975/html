function Point(input) {
   
   if (input) {
      this.x = input.x;
      this.y = input.y;
   }
   else {
      this.x = 0;
      this.y = 0;
   }
   
   this.offset = function(offset) {
      return new Point(
         {
            x: this.x + offset.x,
            y: this.y + offset.y
         }
      );
   }
   
   this.scale = function(scale) {
      return new Point(
         {
            x: this.x * scale,
            y: this.y * scale
         }
      );
   }
   
   this.negative = function() {
      return new Point(
         {
            x: -this.x,
            y: -this.y
         }
      );
   }
   
   this.subtract = function(point) {
      return new Point(
         {
            x: this.x - point.x,
            y: this.y - point.y
         }
      )
   }
   
   this.minimum = function(point) {
      return new Point(
         {
            x: this.x <= point.x ? this.x : point.x,
            y: this.y <= point.y ? this.y : point.y
         }
      );
   }

   this.maximum = function(point) {

      return new Point(
         {
            x: (this.x >= point.x) ?
                  this.x : point.x,
            y: (this.y >= point.y) ?
                  this.y : point.y
         }
      );
   }

   this.distance = function(point) {
      var dx = this.x - point.x;
      var dy = this.y - point.y;
      return Math.sqrt(dx * dx + dy * dy);
   }

   this.middle = function(point) {
      return new Point(
          {
             x: (this.x + point.x) / 2,
             y: (this.y + point.y) / 2
          }
      );
   }
   
   this.screenToCanvas = function(canvas) {
      return this.transform(
         canvas.inverse
      );
   }
   
   this.transform = function(matrix) {
      
      var transform = 
         new Matrix(3, 1,
            [
               this.x,
               this.y,
               1
            ]
         );

      
      var transformed = 
         matrix.multiply(transform);
      
      var point = new Point(
         {
            x: transformed.array[0],
            y: transformed.array[1]
         }
      );
      
      return point;
   }

   
   this.round = function(precision) {
   
      if (!precision)
         precision = 0;
         
      var x = Math.round(this.x * Math.pow(10, precision)) / Math.pow(10, precision);
      var y = Math.round(this.y * Math.pow(10, precision)) / Math.pow(10, precision);

      return new Point(
         {
            x: x,
            y: y
         }
      );
   }
   
   this.equals = function(point) {
      return (this.x == point.x &&
              this.y == point.y);
   }
   
   

   this.toString = function() {
      return JSON.stringify(this);
   }
   
}