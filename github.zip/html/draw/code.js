function Code(input) {

   var drawing = input.drawing;
   this.id = input.id;
   
   var parent = input.parent;
   
   var pre = document.createElement("pre");
   pre.id = this.id;
   pre.style.position = "absolute";
   pre.style.top = "0px";
   pre.style.left = "0px";
   pre.style.right = "0px"
   pre.style.height = "100%";
   pre.style.backgroundColor = "lightblue";
   
   var code = document.createElement("code");
   
   code.contentEditable = true;
   code.style.position = "absolute";
   code.style.width = "100%";
   code.style.top = "0px";
   code.style.left = "0px";
   code.style.height = "90vh";
   code.style.fontSize = "4.25vw";
   code.style.overflowY = "scroll";
   
   pre.appendChild(code);
   
   var statements = drawing.statements;
   


   var text;
   if (statements)
      text = statements.join("\n");
   else
      text = "";
      
   code.innerText= text;
   
   var ok = document.createElement("button");
   ok.innerHTML = "OK";
   ok.style.position = "absolute";
   ok.style.left = "0px";
   ok.style.width = "50%";
   ok.style.bottom = "0px";
   ok.style.height = "10vh";
  // ok.style.fontSize = "8vh";
   ok.onclick = function(event) {
     
      if (confirm("Accept changes?")) {
         drawing.setStatements(code.innerText.split("\n"));
     
         parent.removeChild(pre);
      }
   }
   pre.appendChild(ok);
  
   var cancel = document.createElement("button");
   cancel.innerHTML = "Cancel";
   cancel.style.position = "absolute";
   cancel.style.left = "50%";
   cancel.style.width = "50%";
   cancel.style.bottom = "0px";
   cancel.style.height = "10vh";
//   cancel.style.fontSize = "8vh";
   cancel.onclick = function(event) {
      if (confirm("Cancel?")) {
         parent.removeChild(pre);
      }
   }
   pre.appendChild(cancel);
   
   if (parent) {
      parent.appendChild(pre);
      code.focus();
   }
}