function Drawing(input) {
   var drawing = this;
 
   if (input && input.id)
      this.id = input.id;
   else
      this.id = null;
      
   if (input && input.lines)
      this.lines = input.lines;
   else
      this.lines = [];
      
   if (input && input.drawings)
      this.drawings = input.drawings;
   else
      this.drawings = [];
      
   var parent = input.parent;
   var statements = input.statements;
   var dimensions = new Dimensions();
   var f = null;
   var currentLine = null;
   
   this.isCurrentDrawing = 
      input.isCurrentDrawing ?
         input.isCurrentDrawing :
         false;
         
   
   this.onpendown = function(point) {}
   this.onmovepen = function(point) {}
   this.onpenup = function(point) {}
   this.onclick = function(point) {}
   this.ondoubleclick = function(point) {}
   this.oncontextmenu = function(point) {}
   this.ondraw = function(context) {}
   

   this.draw = function(context) {
      if (this.isCurrentDrawing) {
         dimensions.draw(context);
         context.strokeStyle = "blue";
         context.fillStyle = "blue";
      }
      else {
         if (f && this.statements) {
            context.strokeStyle = "green";
            context.fillStyle = "green";
            }
         else  {
            context.strokeStyle = "red";
            context.fillStyle = "red";
         }
      }

      this.lines.forEach(
         function(line) {
            line.draw(context);
         }
      );
     
      if (this.statements)
         this.drawText(context);

      this.ondraw(context);
   }

   
   this.drawText = function(context) {
    
      context.fillStyle = "black";
      context.strokeStyle = "black";
      
      context.font = "20px Courier new";
      
      var dim = dimensions;
      var top = dim.top + 20;

      this.statements.forEach(
         function(statement) {
            context.fillText(
               statement,
               dim.left,
               top
            );
            top += 22;
         }
      );
      0
   }
   
   this.penDown = function(point) {

      currentLine = new Line(
         {
            start: point
         }
      );
      this.lines.push(currentLine);
      
      this.onpendown(point)
   }
   
   this.movePen = function(point) {
      currentLine.points.push(point);
      this.onmovepen(point);
   }
   
   this.penUp = function(point) {
      currentLine.setDimensions();
      currentLine = null;
      var drawing = this;
      while (drawing) {
         drawing.setDimensions();
         drawing = drawing.parent;
      }
      this.onpenup(point);
   }

   this.click = function(point) {
      this.onclick(point);
   }
   
   this.contextmenu = function(point) {
      try {
         
         var code = new Code(
            {
               parent: parent,
               drawing: this
            }
         );
         
         
      
         this.oncontextmenu(point);
      }
      catch (error) {
         Debug.catch(error);
      }
   }
   
   this.getDimensions = function () {
      return dimensions;
   }
   
   this._setDimensions = function(dim) {
      dimensions = dim;
   }
   
   this.setDimensions = function() {
      
      this.clearDimensions();
      var minimum = dimensions.minimum;
      var maximum = dimensions.maximum;
      
      this.lines.forEach(
         function (line) {
            var dim = line.getDimensions();

            minimum = dim.minimum.minimum(minimum);

            maximum = dim.maximum.maximum(maximum);
         }
         
      );
      
      this.drawings.forEach(
         function(drawing) {
            var dim = drawing.getDimensions();

            minimum = dim.minimum.minimum(minimum);

            maximum = dim.maximum.maximum(maximum);

         }
      );
      
      dimensions = new Dimensions(
         {
            minimum: minimum,
            maximum: maximum
         }
      );
      
      // adjust all parent drawings
      var drawing = this.getParent();
      while (drawing) {
         
         dim = drawing.getDimensions();

         minimum = dim.minimum.minimum(minimum);

         maximum = dim.maximum.maximum(maximum);

         drawing._setDimensions(
            new Dimensions(
               {
                  minimum,
                  maximum
               }
            )
         );
         
         drawing = drawing.getParent();
      }
    
   }
   
   this.clearDimensions = function() {
         
      dimensions = new Dimensions();

   }
   
   function getMatrix(drawing) {
   
      var matrix = Matrix3x3.Identity;
      
      if (!drawing.getParent())
         return matrix;
         
      return matrix;
   
   }
   
   this.setStatements = function(statements) {
      this.statements = statements;
      f = null;
      if (this.statements) {
         try {
            f = new Function("input", this.statements.join("\n"));
         }
         catch (error) {
            f = null;
            Debug.catch(error);
         }
      }
     
   }
   
   this.doubleClick = function(point) {
      var object;
      
      if (f) {
         try {
            object = new f(
               {
                  drawing: this
               }
            );
         }
         catch (err) {
            Debug.catch(err);
         }
      }
      
      this.ondoubleclick();
      
   }
   
   this.getF = function() {
      return f;
   }
   
   this.isPointInside = function(point) {
      var dim = dimensions;
      return point.x >= dim.minimum.x
         && point.x <= dim.maximum.x
         && point.y >= dim.minimum.y
         && point.y <= dim.maximum.y;
   }

   this.contains = function(drawing) {
      var dim = dimensions;
      containsDim = drawing.dimensions;
      return (dim.left <= containsDim.left
         && dim.right >= containsDim.right
         && dim.top <= containsDim.top
         && dim.bottom >= containsDim.bottom);
   }
   
   this.getParent = function() {
      return parent;
   }
   
   // set the new parent
   this.setParent = function(newParent) {
   
      var oldParent = parent;
         
      // remove the drawing from the 
      // old parents array of drawings
      var array = oldParent.drawings;
      
      var index = oldDrawings.indexOf(this);
      
      var head = oldDrawings.slice(0, index);

      var tail = oldDrawings.slice(index + 1);
      
      array = head.concat(tail);
      
      oldParent.drawings = array;
      
      // add the drawing to its parent
      newParent.drawings.push(this);
         
      parent = newParent;
   }

   this.save = function(input) {
      var string = this.toString();
      localStorage.setItem(input.key, string);
   }

   this.toString = function() {
   
      return JSON.stringify(this);

   }
   
   this.toShortString = function() {
     
      var str = "{statements: [" + this.statements.join(",") + "]";
      str += ",drawings:[";
      for (index = 0; index < this.drawings.length; index++) {
         var drawing = this.drawings[index];
         str += drawing.toShortString();
         if (index < this.drawings.length - 1)
            str += ",";
      }
      str += "]}";
      return str;
   }
   
   this.matrix = getMatrix(this);
   this.setDimensions();
   if (statements)
      this.setStatements(statements);
   
}

Drawing.load = function(input) {

   var object;
   
   if (input.object)
      object = input.object;
   else if (input.key) {
      // get the drawing from local storage using the input key
      var string = localStorage.getItem(input.key);
   
      // get the object from the string
      object = JSON.parse(string);
   }
   
   // create the root node to traverse the drawing hierachy
   var root = new Node(
      {
         leaf: object,
         getChildren:
            function(drawing) {
               return drawing.drawings;
            }
      }
   );
   
   var rootDrawing = null;
   
   // loop through the drawing hierachy
   for (
           var node = root;
           node != null;
           node = node.next()
       ) {
   
      // prepare to create the drawing
      var input = node.leaf;
      
      // set the parent
      input.parent = node.parent ?
         node.parent.drawing :
         null;
         
      // create the lines
      var lines = [];
      if (input && input.lines) {
         input.lines.forEach(
            function (line) {
               lines.push(
                  new Line(line)
               );
            }
         );
      }
      // set the lines
      input.lines = lines;
      
      // remove the child drawings as the tree traversal will set them for us
      input.drawings = null;
      
      // create the drawing
      var drawing = new Drawing(
         input
      );
       
      // save the drawing so we can set its childrens parents in the next round
      node.drawing = drawing;
      
      // add the drawing to its parent
      if (node.parent) {
         
         var drawings = node.parent.drawing.drawings;

         drawings.push(drawing);
      }
      
      // save the root drawing
      if (node == root)
         rootDrawing = drawing;
         
   }
   
   return rootDrawing;
}
