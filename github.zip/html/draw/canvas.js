
function Canvas(input) {
   
   var canvas = this;

   if (input && input.id)
      this.id = input.id;
   else
      this.id = null;
   
   if (input)
      this.drawing = new Drawing(input.drawing);
   
   if (input && input.width)
      this.width = input.width;
   else
      this.width = 500;
      
   if (input && input.width)
      this.height = input.height;
   else
      this.height = 500;
      
   var parent;
   if (input && input.parent)
      parent = input.parent;
   else
      parent = null;
      
   var events;
   if (input && input.events)
      events = input.events;
      
   var currentDrawing = null;
   var context = null;
   var lastTimestamp = null;

   var pixelRatio = window.devicePixelRatio;
   
   this.matrix = Matrix3x3.Identity
      .scale(
         new Point(
            {
               x: pixelRatio,
               y: pixelRatio
            }
         )
      );
   
   this.inverse = Matrix3x3.Identity;

   this.scale = 1.0;
   
   // declare canvas on events
   declareEvents();
   
   // create the html canvas element
   var element = createCanvasElement();

   // setup the body resize handler
   setupResizeEvent();
   
   // click on the drawing
   events.onclick = function(point) {

      if (currentDrawing) {
         currentDrawing.isCurrentDrawing = false;
         canvas.draw();
      }
      
      var hit = canvas.hitTest(point);
    
      currentDrawing = hit;
      
      if (currentDrawing)
         currentDrawing.isCurrentDrawing = true;
         
      canvas.draw();

      if (hit != null)
         hit.click(point);
      
      canvas.onclick(point);
    
   }
   

   events.ondoubleclick = function(point) {
      if (currentDrawing != null) {
         currentDrawing.doubleClick(point);

      }
      canvas.draw();
      canvas.ondoubleclick(event);
   }
   
   events.oncontextmenu = function(point) {
      
      if (currentDrawing)
         currentDrawing.isCurrentDrawing = false;
         
      var hit = canvas.hitTest(point);
      
      currentDrawing = hit;
      
      if (currentDrawing)
         currentDrawing.isCurrentDrawing = true;
         
      canvas.draw();
      
      if (currentDrawing)
         currentDrawing.oncontextmenu(point);
      
      canvas.oncontextmenu(point);
      
   }

   this.hitTest = function(point) {
      var root = new Node(
         {
            leaf: this.drawing,
            getChildren: 
               function(drawing) {
                  return drawing.drawings;
               }
            
         }
      );
      var hit = null;
      var node = root;
      while (node) {
         var drawing = node.leaf;
         if (drawing.isPointInside(point))
            hit = drawing;
         else
            // Missed this node, so
            // skip its children
            delete node.children;
        
         
         node = node.next();
      }
      
      return hit;
     
   }   

   events.onpendown = function(point) {
  
      if (!currentDrawing) {
         
         currentDrawing = new Drawing(
            {
               parent: this.drawing,
               isCurrentDrawing: true
            }
         );
         
         canvas.drawing.drawings.push(currentDrawing);
         
      }
      currentDrawing.penDown(point);
      
      context.strokeStyle = "blue";
      context.beginPath();
      context.moveTo(point.x, point.y);
      
      
      
      canvas.onpendown(point);
   }

   events.onmovepen = function(point) {
     
      context.lineTo(point.x, point.y);
      
      context.stroke();
      
      currentDrawing.movePen(point);
      
      canvas.onmovepen(point);

      
   }

   events.onpenup = function(point) {
     
      currentDrawing.penUp(point);

      canvas.onpenup(point);
   } 
   
   this.getParent = function() {
      return parent;
   }

   events.ontransform = function(offset, center, scale) {
      
      // scale around the center then offset
      canvas.matrix = 
         canvas.matrix
         .translate(
            offset
         )
         .translate(
            center
         )
         .scale(
            new Point(
               {
                  x: scale,
                  y: scale
               }
            )
         )
         .translate(
            center.negative()
         );
       
      canvas.scale = canvas.matrix.array[0];
      
      // inverse is the reflection or opposite of matrix
      // it allows us to map between screen coordinates and our coordinate system
      canvas.inverse =
         Matrix3x3.Identity
         .translate(
            center
         )
         .scale (
            new Point(
               {
                  x: 1 / scale, 
                  y: 1 / scale
               }
            )
         )
         .translate(
            center.negative()
         )
         .translate(
            offset.negative()
         )
         .multiply(canvas.inverse);

       
       canvas.draw();
       
       canvas.ontransform(canvas.matrix);
   }
   
   events.ontransformpoint = function(point) {
      var transformed = point.screenToCanvas(canvas);
      return transformed;
   }
   
   // Enque the draw() function,
   // when the window requests the
   // next animation frame.
   // make sure we only queue the
   // function once, regardless of
   // how many times we are called
   this.draw = function () {

      window.requestAnimationFrame(
         function (timestamp) {
            if (lastTimestamp != timestamp)
               draw();
         
            lastTimestamp = timestamp;
         }
      
      );
      
   
      function draw() {
 
         
         // force a resize
         resize();
      
         var context = canvas.getContext();
         context.resetTransform();
         context.clearRect(0, 0, canvas.width, canvas.height);
         context.strokeStyle = "blue";
         context.lineWidth = (1/canvas.scale);

         canvas.matrix.applyToContext(
            context
         );
         
         var node = new Node(
            {
               leaf: canvas.drawing,
               getChildren:
                  function getChildren(drawing) {
                     return drawing.drawings;
                   }
            }
         );
           
         while (node) {
         
            var drawing = node.leaf;
            
            context.save();
            
            drawing.draw(context);
            
            context.restore();
            
            node = node.next();
         }
      
         canvas.ondraw(context);
      
      }
      
      function resize(event) {
   
         var width, height;
      
         if (parent) {   
            width = parent.clientWidth * pixelRatio;
            height = parent.clientHeight * pixelRatio;
         
         }
         else {
            width = canvas.width;
            height = canvas.height;
         }
      
         var changedSize = false;
      
         if (width != element.width) {
            changedSize = true;
            element.width = canvas.width = width;
         }
      
         if (height != element.height) {
            changedSize = true;
            element.height = canvas.height = height;
         }
      
         if (changedSize) {
            canvas.draw();
            canvas.onresize();
         }
      }
   }
   
   function createCanvasElement() {
      var element = document.createElement("canvas");

      element.id = canvas.id;
      
element.style.position = "absolute";
      element.style.left = "0px";
      element.style.top = "0px";
      element.style.width = "100%";
      element.style.height = "100%";
         
      if (parent) {
         parent.appendChild(element);
      }
      
      
      return element;
   }
   
   function declareEvents() {
   
      canvas.onclick = function(point) {}
      canvas.ondoubleclick = function(point) {}
      canvas.oncontextmenu = function(point) {}
      canvas.onpendown = function(point) {}
      canvas.onmovepen = function(point) {}
      canvas.onpenup = function(point) {}
      canvas.onsetmatrix = function() {}
   
      canvas.ondraw = function(context) {}
   
      canvas.onresize = function(context) {}
   
      canvas.ontransform = function(matrix) {}
      
   }
   
   function setupResizeEvent() {

      if (parent)
         document.body.onresize = function(event) {
            canvas.draw();
         }

   }
   
   this.getContext = function() {
      if (context == null)
         context = element.getContext("2d");
      return context;
   }
   
   this.toString = function () {
      return JSON.stringify(this);
   }
   
   this.draw();

   this.load = function(key) {
      if (currentDrawing)
         currentDrawing.isCurrentDrawing = false;
      currentDrawing = null;
      
      var drawing = Drawing.load(
         {
            key: key
         }
      );
      
      this.drawing = drawing;
      
      this.draw();
      
      return drawing;
   }
   
   this.save = function(key) {
      if (currentDrawing)
         currentDrawing.isCurrentDrawing = false;
      currentDrawing = null;
      
      this.drawing.save(
         {
            key: key
         }
      );
      
      this.draw();
   }
}