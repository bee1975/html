Matrix3x3 = {};
Matrix3x3.Identity = 
   new Matrix(3, 3,
      [
         1, 0, 0,
         0, 1, 0,
         0, 0, 1
      ]
   );

Matrix3x3.fromTranslate = function(translate) {
   return new Matrix(3, 3,
      [
         1, 0, translate.x,
         0, 1, translate.y,
         0, 0, 1
      ]
   );
}

Matrix.prototype.translate =
function(translate) {
   return this.multiply(
      Matrix3x3.fromTranslate(translate)
   );
}

Matrix3x3.fromScale = function(scale) {
   return new Matrix(3, 3,
      [
         scale.x, 0, 0,
         0, scale.y, 0,
         0, 0, 1
      ]
   );
}
Matrix.prototype.scale =
function(scale) {
   return this.multiply(
      Matrix3x3.fromScale(scale)
   );
}

Matrix.prototype.applyToContext =
   function(context) {
      
      //  a, c, e
      //  b, d, f
      //  0, 0, 1
      
      //  0, 1, 2,
      //  3, 4, 5,
      //  6, 7, 8
      
      var m = this.array

      context.setTransform(
         m[0], // a
         m[3], // b
         m[1], // c
         m[4], // d
         m[2], // e
         m[5]  // f
      );

   }
   
Matrix.prototype.applyToElement =
   function(element) {

      var m = this.array;
      
      element.style.transform =
         "matrix(" +
            m[0] + ", " + // a
            m[3] + ", " + // b
            m[1] + ", " + // c
            m[4] + ", " + // d
            m[2] + ", " + // e
            m[5] + // f
         + ")";
         
      element.style.transformOrigin = "top left";

   }
