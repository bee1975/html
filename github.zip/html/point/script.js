function Point(input) {

   this.x = input.x;
   this.y = input.y;
  
   this.offset = function(offset) {
      return new Point(
         {
            x: this.x + offset.x,
            y: this.y + offset.y
         }
      );
   }
   
   this.scale = function(scale) {
      return new Point(
         {
            x: this.x * scale,
            y: this.y * scale
         }
      );
   }
   
   this.negative = function() {
      return new Point(
         {
            x: -this.x,
            y: -this.y
         }
      );
   }
   
   this.subtract = function(point) {
      return new Point(
         {
            x: this.x - point.x,
            y: this.y - point.y
         }
      )
   }
   
   this.minimum = function(point) {
      return new Point(
         {
            x: this.x <= point.x ?
                  this.x : point.x,
            y: this.y <= point.y ?
                  this.y : point.y
         }
      );
   }

   this.maximum = function(point) {

      return new Point(
         {
            x: (this.x >= point.x) ?
                   this.x : point.x,
            y: (this.y >= point.y) ?
                   this.y : point.y
         }
      );
   }

   this.distance = function(point) {
      let dx = this.x - point.x;
      let dy = this.y - point.y;
      return Math.sqrt(dx * dx + dy * dy);
   }

   this.middle = function(point) {
      return new Point(
         {
            x: (this.x + point.x) / 2,
            y: (this.y + point.y) / 2
         }
      );
   }
   
   this.screenToCanvas = function(canvas) {
      return  this.transform(canvas.matrix);
   }
   
   this.transform = function(matrix) {
      
      let transform = 
         new Matrix(3, 1,
            [
               this.x,
               this.y,
               1
            ]
         );

      
      let transformed = 
         matrix.multiply(transform);
      
      let point = new Point(
         {
            x: transformed.array[0],
            y: transformed.array[1]
         }
      );
      
      return point;
   }

   
   this.round = function(precision) {
      return new Point(
         {
            x: this.x.round(precision),
            y: this.y.round(precision)
         }
      );
   }
   
   this.equals = function(point) {
      return (this.x == point.x &&
              this.y == point.y);
   }
   
}